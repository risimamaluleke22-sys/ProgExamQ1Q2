/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4Suite.java to edit this template
 */
package com.mycompany.salesreportforlocalcompany;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 *
 * @author Risima Maluleke
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({com.mycompany.salesreportforlocalcompany.IProductCalculationsTest.class, com.mycompany.salesreportforlocalcompany.PrintProductTest.class, com.mycompany.salesreportforlocalcompany.ProductTest.class, com.mycompany.salesreportforlocalcompany.ProductCalculationsTest.class, com.mycompany.salesreportforlocalcompany.IProductsTest.class})
public class SalesreportforlocalcompanySuite {

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }
    
}
