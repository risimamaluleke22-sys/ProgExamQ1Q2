/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.salesreportforlocalcompany;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Risima Maluleke
 */
public class IProductsTest {
    
    public IProductsTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getTotalProductsSold method, of class IProducts.
     */
    @Test
    public void testGetTotalProductsSold() {
        System.out.println("getTotalProductsSold");
        IProducts instance = new IProductsImpl();
        int expResult = 0;
        int result = instance.getTotalProductsSold();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getAverageProductSold method, of class IProducts.
     */
    @Test
    public void testGetAverageProductSold() {
        System.out.println("getAverageProductSold");
        IProducts instance = new IProductsImpl();
        double expResult = 0.0;
        double result = instance.getAverageProductSold();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getMostPopularProduct method, of class IProducts.
     */
    @Test
    public void testGetMostPopularProduct() {
        System.out.println("getMostPopularProduct");
        IProducts instance = new IProductsImpl();
        String expResult = "";
        String result = instance.getMostPopularProduct();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    public class IProductsImpl implements IProducts {

        public int getTotalProductsSold() {
            return 0;
        }

        public double getAverageProductSold() {
            return 0.0;
        }

        public String getMostPopularProduct() {
            return "";
        }
    }
    
}
