/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.salesreportforlocalcompany;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Risima Maluleke
 */
public class IProductCalculationsTest {
    
    public IProductCalculationsTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getVat method, of class IProductCalculations.
     */
    @Test
    public void testGetVat() {
        System.out.println("getVat");
        IProductCalculations instance = new IProductCalculationsImpl();
        double expResult = 0.0;
        double result = instance.getVat();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getCommission method, of class IProductCalculations.
     */
    @Test
    public void testGetCommission() {
        System.out.println("getCommission");
        IProductCalculations instance = new IProductCalculationsImpl();
        double expResult = 0.0;
        double result = instance.getCommission();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTotal method, of class IProductCalculations.
     */
    @Test
    public void testGetTotal() {
        System.out.println("getTotal");
        IProductCalculations instance = new IProductCalculationsImpl();
        double expResult = 0.0;
        double result = instance.getTotal();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    public class IProductCalculationsImpl implements IProductCalculations {

        public double getVat() {
            return 0.0;
        }

        public double getCommission() {
            return 0.0;
        }

        public double getTotal() {
            return 0.0;
        }
    }
    
}
