/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.salesreportforlocalcompany;

/**
 *
 * @author Risima Maluleke
 */
public class PrintProduct {

    public static void main(String[] args) {

        IProducts report = new Product();

        System.out.println("================================");
        System.out.println("       PRODUCT SALES REPORT");
        System.out.println("================================");

        System.out.println("Total products sold: "
                + report.getTotalProductsSold());

        System.out.printf("Average products sold per product: %.2f%n",
                report.getAverageProductSold());

        System.out.println("Most popular product: "
                + report.getMostPopularProduct());

        System.out.println("================================");
    }
}
