/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.salesreportforlocalcompany;

/**
 *
 * @author Risima Maluleke
 */
  public interface IProducts {
    int getTotalProductsSold();
    double getAverageProductSold();
    String getMostPopularProduct();
}

