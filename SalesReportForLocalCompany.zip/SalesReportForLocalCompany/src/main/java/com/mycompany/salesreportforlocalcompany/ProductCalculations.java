/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.salesreportforlocalcompany;

/**
 *
 * @author Risima Maluleke
 */
public class ProductCalculations implements IProductCalculations {

    private double productPrice;

    public ProductCalculations(double productPrice) {
        this.productPrice = productPrice;
    }

    public void setProductPrice(double productPrice) {
        this.productPrice = productPrice;
    }

    @Override
    public double getVat() {
        return productPrice * 15 / 100;
    }

    @Override
    public double getCommission() {
        return productPrice * 5 / 100;
    }

    @Override
    public double getTotal() {
        return productPrice + getVat() + getCommission();
    }
}
