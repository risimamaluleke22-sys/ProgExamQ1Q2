/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.salesreportforlocalcompany;

/**
 *
 * @author Risima Maluleke
 */
    public class Product implements IProducts {

    private final String[] names = {
        "Cozy Nights Monarch",
        "Resilience Barbados",
        "Sealy Phuket"
    };

    private final int[][] monthlySales = {
        {25, 18, 20},
        {15, 10, 12},
        {18, 15, 20}
    };

    @Override
    public int getTotalProductsSold() {
        int sum = 0;

        for (int[] month : monthlySales) {
            for (int quantity : month) {
                sum += quantity;
            }
        }

        return sum;
    }

    @Override
    public double getAverageProductSold() {
        return (double) getTotalProductsSold()
                / monthlySales.length;
    }

    @Override
    public String getMostPopularProduct() {
        int bestIndex = 0;
        int bestSales = -1;

        for (int i = 0; i < monthlySales.length; i++) {
            int productTotal = 0;

            for (int quantity : monthlySales[i]) {
                productTotal += quantity;
            }

            if (productTotal > bestSales) {
                bestSales = productTotal;
                bestIndex = i;
            }
        }

        return names[bestIndex];
    }
}
