/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.guimattressapplication;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.FileWriter;
import java.io.IOException;
/**
 *
 * @author Risima Maluleke
 */
public class ProductApplication extends JFrame {
    private JTextField txtCustomerName;
    private JComboBox<String> cmbProduct;
    private JTextField txtPrice;
    private JButton btnProcess;

    public ProductApplication() {
        setTitle("Product App");
        setSize(350, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(5, 2, 10, 10));

        // Q2.2 - Controls
        add(new JLabel("Customer Name:"));
        txtCustomerName = new JTextField();
        add(txtCustomerName);

        add(new JLabel("Select Product:"));
        cmbProduct = new JComboBox<>(new String[]{
            "Cosy Nights Monarch", "Restonic Barbados", "Sealy Phuket"});
        add(cmbProduct);

        add(new JLabel("Enter Price:"));
        txtPrice = new JTextField();
        add(txtPrice);

        btnProcess = new JButton("PROCESS");
        add(new JLabel(""));
        add(btnProcess);

        // Q2.4 - Menu System
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        fileMenu.add(exitItem);

        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem processItem = new JMenuItem("Process");
        JMenuItem clearItem = new JMenuItem("Clear");
        toolsMenu.add(processItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        setJMenuBar(menuBar);

        // Button + Menu actions
        btnProcess.addActionListener(e -> processSale());
        processItem.addActionListener(e -> processSale());
        exitItem.addActionListener(e -> System.exit(0));
        clearItem.addActionListener(e -> {
            txtCustomerName.setText("");
            txtPrice.setText("");
            cmbProduct.setSelectedIndex(0);
        });
    }

    // Q2.3 - Process + Save to file
    private void processSale() {
        try {
            String customer = txtCustomerName.getText();
            String productName = (String) cmbProduct.getSelectedItem();
            double price = Double.parseDouble(txtPrice.getText());

            ProductCalculations calc = new ProductCalculations(price);
            double vat = calc.GetVat();
            double commission = calc.GetCommission();
            double total = calc.GetTotal();

            String message = "Customer Name: " + customer +
                "\nProduct: " + productName +
                "\nVAT: R " + vat +
                "\nCOMMISSION: R " + commission +
                "\nTOTAL: R " + total;
            JOptionPane.showMessageDialog(this, message);

            // Save to data.txt
            try (FileWriter writer = new FileWriter("data.txt", true)) {
                writer.write("************************\n");
                writer.write("DATA LOG\n");
                writer.write("************************\n");
                writer.write("Customer Name: " + customer + "\n");
                writer.write("Product: " + productName + "\n");
                writer.write("VAT: R " + vat + "\n");
                writer.write("COMMISSION: R " + commission + "\n");
                writer.write("TOTAL: R " + total + "\n");
                writer.write("************************\n");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid price.");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error saving to file.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ProductApplication().setVisible(true));
    }
}
