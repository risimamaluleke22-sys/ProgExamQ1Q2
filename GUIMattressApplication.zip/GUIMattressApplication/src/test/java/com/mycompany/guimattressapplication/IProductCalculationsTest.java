/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.guimattressapplication;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Risima Maluleke
 */
public class IProductCalculationsTest {
    
    public IProductCalculationsTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of GetVat method, of class IProductCalculations.
     */
    @Test
    public void testGetVat() {
        System.out.println("GetVat");
        IProductCalculations instance = new IProductCalculationsImpl();
        double expResult = 0.0;
        double result = instance.GetVat();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of GetCommission method, of class IProductCalculations.
     */
    @Test
    public void testGetCommission() {
        System.out.println("GetCommission");
        IProductCalculations instance = new IProductCalculationsImpl();
        double expResult = 0.0;
        double result = instance.GetCommission();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of GetTotal method, of class IProductCalculations.
     */
    @Test
    public void testGetTotal() {
        System.out.println("GetTotal");
        IProductCalculations instance = new IProductCalculationsImpl();
        double expResult = 0.0;
        double result = instance.GetTotal();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    public class IProductCalculationsImpl implements IProductCalculations {

        public double GetVat() {
            return 0.0;
        }

        public double GetCommission() {
            return 0.0;
        }

        public double GetTotal() {
            return 0.0;
        }
    }
    
}
